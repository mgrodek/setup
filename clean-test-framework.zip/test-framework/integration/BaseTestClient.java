
import lombok.RequiredArgsConstructor;
import lombok.val;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.util.UriBuilder;

import java.net.URI;
import java.util.Locale;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

@RequiredArgsConstructor
public abstract class BaseTestClient {

    private static final Locale ENGLISH_LOCALE = Locale.forLanguageTag("en-US");

    protected final WebTestClient testClient;

    protected abstract String basePath();

    protected WebTestClient.ResponseSpec doGet(Consumer<HttpHeaders> headers) {
        return doGet(null, headers);
    }

    protected WebTestClient.ResponseSpec doGet(UriConfigurer uriConfigurer) {
        return doGet(uriConfigurer, null);
    }

    protected WebTestClient.ResponseSpec doGet(UriConfigurer uriConfigurer, Consumer<HttpHeaders> headers) {
        return testClient
                .get()
                .uri(buildUriFunction(uriConfigurer))
                .headers(buildHeaders(headers))
                .accept(MediaType.APPLICATION_JSON)
                .exchange();
    }

    protected WebTestClient.ResponseSpec doPost(Object body) {
        return doPost(null, null, body);
    }

    protected WebTestClient.ResponseSpec doPost(Consumer<HttpHeaders> headers, Object body) {
        return doPost(null, headers, body);
    }

    protected WebTestClient.ResponseSpec doPost(UriConfigurer uriConfigurer, Object body) {
        return doPost(uriConfigurer, null, body);
    }

    protected WebTestClient.ResponseSpec doPost(UriConfigurer uriConfigurer, Consumer<HttpHeaders> headers, Object body) {
        return testClient
                .post()
                .uri(buildUriFunction(uriConfigurer))
                .headers(buildHeaders(headers))
                .accept(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange();
    }

    protected WebTestClient.ResponseSpec doPut(UriConfigurer uriConfigurer) {
        return doPut(uriConfigurer, null);
    }

    protected WebTestClient.ResponseSpec doPut(UriConfigurer uriConfigurer, Consumer<HttpHeaders> headers) {
        return testClient
                .put()
                .uri(buildUriFunction(uriConfigurer))
                .headers(buildHeaders(headers))
                .accept(MediaType.APPLICATION_JSON)
                .exchange();
    }

    protected WebTestClient.ResponseSpec doPut(UriConfigurer uriConfigurer, Object body) {
        return doPut(uriConfigurer, null, body);
    }

    protected WebTestClient.ResponseSpec doPut(UriConfigurer uriConfigurer, Consumer<HttpHeaders> headers, Object body) {
        return testClient
                .put()
                .uri(buildUriFunction(uriConfigurer))
                .headers(buildHeaders(headers))
                .accept(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange();
    }

    protected WebTestClient.ResponseSpec doDelete(UriConfigurer uriConfigurer) {
        return doDelete(uriConfigurer, null);
    }

    protected WebTestClient.ResponseSpec doDelete(UriConfigurer uriConfigurer, Consumer<HttpHeaders> headers) {
        return testClient
                .delete()
                .uri(buildUriFunction(uriConfigurer))
                .headers(buildHeaders(headers))
                .accept(MediaType.APPLICATION_JSON)
                .exchange();
    }

    protected Consumer<HttpHeaders> authorizationHeaders(String token) {
        return httpHeaders ->
                httpHeaders.set(HttpHeaders.AUTHORIZATION, "Bearer " + token);
    }

    protected Consumer<HttpHeaders> languageHeader(Locale acceptLanguage) {
        return httpHeaders -> Optional.ofNullable(acceptLanguage)
                .map(Locale::toLanguageTag)
                .ifPresent(tag -> httpHeaders.set(HttpHeaders.ACCEPT_LANGUAGE, tag));
    }

    private Function<UriBuilder, URI> buildUriFunction(UriConfigurer builder) {
        return uriBuilder -> {
            val uriComponentsBuilder = uriBuilder.path(basePath());
            Optional.ofNullable(builder).ifPresent(b -> b.configure(uriComponentsBuilder));
            return uriComponentsBuilder.build();
        };
    }

    private Consumer<HttpHeaders> buildHeaders(Consumer<HttpHeaders> customHeaders) {
        return httpHeaders -> {
            languageHeader(ENGLISH_LOCALE).accept(httpHeaders);
            Optional.ofNullable(customHeaders)
                    .ifPresent(consumer -> consumer.accept(httpHeaders));
        };
    }

}