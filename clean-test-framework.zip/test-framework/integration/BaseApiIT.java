import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.testcontainers.containers.MockServerContainer;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import java.time.Duration;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

@Testcontainers
@ActiveProfiles("it")
@SpringBootTest(webEnvironment = RANDOM_PORT)
public abstract class BaseApiIT<TEST_CLIENT extends BaseTestClient> {

    private static final DockerImageName MOCKSERVER_IMAGE = DockerImageName
            .parse("mockserver")
            .asCompatibleSubstituteFor("jamesdbloom/mockserver")
            .withTag("mockserver-5.15.0");

    private static final MockServerContainer MOCK = new MockServerContainer(MOCKSERVER_IMAGE);

    public static final String SOME_KEY = "SOME_KEY";

    private static SomeApiMock someApiMock;
    private static MockService mock;

    @LocalServerPort
    private int port;

    protected TEST_CLIENT testClient;

    static {
        System.setProperty("SOME_KEY", SOME_KEY);
    }

    public abstract TEST_CLIENT getTestClient(WebTestClient testClient);

    @DynamicPropertySource
    private static void setDynamicProperties(DynamicPropertyRegistry registry) {
        registry.add("api.client.basePath", mock::getSomeApiPath);
        registry.add("api.client.username", () -> "username");
    }

    @BeforeEach
    void beforeEach() {
        this.testClient = getTestClient(
                WebTestClient.bindToServer()
                        .responseTimeout(Duration.ofSeconds(30))
                        .baseUrl("http://localhost:" + port)
                        .build());
    }

    @AfterEach
    void afterEach() {
        mock.reset();
    }

    @BeforeAll
    static void beforeAll() {
        MOCK.start();
        mock = MockService.getInstance(
                MOCK.getHost(),
                MOCK.getServerPort());
        someApiMock = mock.getTokenConverterApiMock();
    }

    protected <V extends BaseApiMock> V getApiMock(Class<V> clazz) {
        return mock.getMockByClass(clazz);
    }
}