import org.springframework.test.context.TestPropertySource;

@TestPropertySource(properties = "api.authorization = false")
public abstract class BaseNoAuthorizationIT<TEST_CLIENT extends BaseTestClient> extends BaseApiIT<TEST_CLIENT> {
}
