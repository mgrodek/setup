
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import org.mockserver.client.MockServerClient;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class MockApiFactory {

    private static final String SOME_API_BASE_PATH = "/some-api";
    private static final String SOME_API_MOCKING_FILES = "some-api";

    private final MockJsonExpectations mockJsonExpectations;

    public static MockApiFactory getInstance(MockServerClient mockServerClient) {
        return new MockApiFactory(
                new MockJsonExpectations(mockServerClient));
    }

    public SomeApiMock aSomeApiMock() {
        return new SomeApiMock(
                SOME_API_BASE_PATH,
                SOME_API_MOCKING_FILES,
                mockJsonExpectations);
    }
}