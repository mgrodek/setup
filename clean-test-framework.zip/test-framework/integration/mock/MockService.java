import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mockserver.client.MockServerClient;
import org.mockserver.model.HttpRequest;

import java.util.Objects;

@Slf4j
@Getter
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public class MockService {

    private static final String MOCK_URL_NO_HTTP = "%s:%d";
    private static final String MOCK_URL_PREFIX = "http://";

    private static MockService mocksService;

    private final String mockRootUrl;
    private final MockServerClient mock;

    @Getter
    private SomeApiMock someApiMock;

    private MockService(String host, int port) {
        this.mock = new MockServerClient(host, port);
        this.mockRootUrl = MOCK_URL_NO_HTTP.formatted(host, port);
        var mockApiFactory = MockApiFactory.getInstance(mock);
        this.someApiMock = mockApiFactory.aTokenConverterApiMock();
    }

    public static MockService getInstance(String host, int port) {
        if (Objects.isNull(mocksService)) {
            mocksService = new MockService(host, port);
        }
        return mocksService;
    }

    public void reset() {
        log.info(mock.retrieveLogMessages(HttpRequest.request()));
        mock.reset();
    }

    public String getSomeApiPath() {
        return MOCK_URL_PREFIX + mockRootUrl + someApiMock.getBasePath();
    }

    public String getUserManagerPath() {
        return mockRootUrl + serviceApiMock.getBasePath();
    }

    // For sure this could be done way better; e.g. using map etc. don't want to rework whole solution at this point
    @SuppressWarnings("unchecked")
    public <V extends BaseApiMock> V getMockByClass(Class<V> clazz) {
        if (clazz == ServiceApiMock.class) {
            return (V) serviceApiMock;
        } else {
            throw new IllegalArgumentException(String.format("Unrecognized mock class {%s}", clazz));
        }
    }
}