
import lombok.RequiredArgsConstructor;
import org.mockserver.client.MockServerClient;
import org.mockserver.matchers.Times;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.Parameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import java.util.List;

import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import static org.mockserver.model.JsonPathBody.jsonPath;

@RequiredArgsConstructor
public class MockJsonExpectations {

    private final MockServerClient mock;

    public int getMockInvocationCounter(String path) {
        return mock.retrieveRecordedRequests(request(path)).length;
    }

    public void getForPath(String path, HttpStatus responseStatus, String responseFile) {
        forPath(HttpMethod.GET, path, responseStatus, responseFile, Times.unlimited());
    }

    public void getForPath(String path, HttpStatus responseStatus, String responseFile, Times times) {
        forPath(HttpMethod.GET, path, responseStatus, responseFile, times);
    }

    public void getForPath(String path, List<Parameter> queryParams, HttpStatus responseStatus, String responseFile) {
        var request = request()
                .withPath(path)
                .withQueryStringParameters(queryParams)
                .withMethod(HttpMethod.GET.name());
        forPath(request, responseStatus, responseFile);
    }

    public void getForPath(String path, JsonRequestBodyExpectation bodyExpectation, HttpStatus responseStatus, String responseFile) {
        var request = request()
                .withPath(path)
                .withBody(jsonPath(bodyExpectation.asPath()))
                .withMethod(HttpMethod.GET.name());
        forPath(request, responseStatus, responseFile);
    }

    public void postForPath(String path, HttpStatus responseStatus, String responseFile) {
        forPath(HttpMethod.POST, path, responseStatus, responseFile, Times.unlimited());
    }

    public void postForPath(String path, JsonRequestBodyExpectation jsonBodyExpectation, HttpStatus responseStatus, String responseFile) {
        var request = request()
                .withPath(path)
                .withBody(jsonPath(jsonBodyExpectation.asPath()))
                .withMethod(HttpMethod.POST.name());
        forPath(request, responseStatus, responseFile);
    }

    public void postForPath(String path, JsonRequestBodyExpectation jsonBodyExpectation, HttpStatus responseStatus) {
        var request = request()
                .withPath(path)
                .withBody(jsonPath(jsonBodyExpectation.asPath()))
                .withMethod(HttpMethod.POST.name());
        forPath(request, responseStatus);
    }

    public void putForPath(String path, JsonRequestBodyExpectation bodyExpectation, HttpStatus responseStatus, String responseFile) {
        var request = request()
                .withPath(path)
                .withBody(jsonPath(bodyExpectation.asPath()))
                .withMethod(HttpMethod.PUT.name());
        forPath(request, responseStatus, responseFile);
    }

    public void putForPath(String path, JsonRequestBodyExpectation bodyExpectation, HttpStatus responseStatus) {
        var request = request()
                .withPath(path)
                .withBody(jsonPath(bodyExpectation.asPath()))
                .withMethod(HttpMethod.PUT.name());
        forPath(request, responseStatus);
    }

    public void deleteForPath(String path, HttpStatus responseStatus, String responseFile) {
        forPath(HttpMethod.DELETE, path, responseStatus, responseFile, Times.unlimited());
    }

    private void forPath(HttpMethod httpMethod, String path, HttpStatus responseStatus, String responseFile, Times times) {
        mock
                .when(
                        request()
                                .withPath(path)
                                .withMethod(httpMethod.name()),
                        times)
                .respond(
                        response()
                                .withBody(responseFile)
                                .withStatusCode(responseStatus.value())
                                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE));
    }

    private void forPath(HttpRequest expectedRequest, HttpStatus responseStatus, String responseFile) {
        mock
                .when(expectedRequest)
                .respond(
                        response()
                                .withBody(responseFile)
                                .withStatusCode(responseStatus.value())
                                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE));
    }

    private void forPath(HttpRequest expectedRequest, HttpStatus responseStatus) {
        mock
                .when(expectedRequest)
                .respond(
                        response()
                                .withStatusCode(responseStatus.value())
                                .withHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE));
    }
}