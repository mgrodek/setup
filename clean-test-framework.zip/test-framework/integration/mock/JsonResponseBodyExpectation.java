
import com.google.common.collect.Maps;
import org.apache.commons.compress.utils.Lists;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public record JsonResponseBodyExpectation(Object responseBody) {

    public static JsonResponseBodyExpectationBuilder aJsonResponseBodyExpectation() {
        return new JsonResponseBodyExpectationBuilder();
    }

    public static class JsonResponseBodyExpectationBuilder {
        private final Map<String, Object> properties = Maps.newHashMap();
        private final List<Map<String, Object>> array = Lists.newArrayList();
        private boolean isArray;

        public JsonResponseBodyExpectationBuilder withProperty(String key, Object value) {
            properties.put(key, value);
            return this;
        }

        public JsonResponseBodyExpectationBuilder withProperty(String key, JsonResponseBodyExpectation nestedObject) {
            properties.put(key, Objects.nonNull(nestedObject) ? nestedObject.responseBody() : null);
            return this;
        }

        public JsonResponseBodyExpectationBuilder withProperty(String key, List<JsonResponseBodyExpectation> nestedObjects) {
            properties.put(key, nestedObjects.stream()
                    .map(JsonResponseBodyExpectation::responseBody)
                    .collect(Collectors.toList()));
            return this;
        }

        public JsonResponseBodyExpectationBuilder asArray() {
            this.isArray = true;
            return this;
        }

        @SuppressWarnings("unchecked")
        public JsonResponseBodyExpectationBuilder withElement(JsonResponseBodyExpectation element) {
            if (isArray) {
                array.add((Map<String, Object>) element.responseBody());
            }
            return this;
        }

        public JsonResponseBodyExpectation build() {
            if (isArray) {
                return new JsonResponseBodyExpectation(array);
            }

            return new JsonResponseBodyExpectation(properties);
        }
    }
}