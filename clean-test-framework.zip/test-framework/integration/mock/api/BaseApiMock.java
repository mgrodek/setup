
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.val;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.util.FileCopyUtils;

import java.io.InputStreamReader;

import static java.nio.charset.StandardCharsets.UTF_8;

@RequiredArgsConstructor
public abstract class BaseApiMock {

    private static final String MOCK_FILES_DIRECTORY = "mocks";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule());

    @Getter
    private final String basePath;

    @Getter
    private final String mockFilesSubdirectory;

    protected final MockJsonExpectations expectJson;

    public String getEndpointPath(String... subPath) {
        return basePath + "/" + String.join("/", subPath);
    }

    public String mockFileAsString(String fileName) {
        return readMockFile(fileName);
    }

    @SneakyThrows
    public String responseBodyExpectationAsString(JsonResponseBodyExpectation responseBodyExpectation) {
        return OBJECT_MAPPER.writeValueAsString(responseBodyExpectation.responseBody());
    }

    @SneakyThrows
    private String readMockFile(String filePath) {
        var resourceLoader = new DefaultResourceLoader();
        return asString(resourceLoader.getResource("classpath:%s".formatted(relativeMockFilePath(filePath))));
    }

    @SneakyThrows
    private String asString(Resource resource) {
        try (val reader = new InputStreamReader(resource.getInputStream(), UTF_8)) {
            return FileCopyUtils.copyToString(reader);
        }
    }

    private String relativeMockFilePath(String responseFile) {
        return MOCK_FILES_DIRECTORY + "/" + mockFilesSubdirectory + "/" + responseFile;
    }
}