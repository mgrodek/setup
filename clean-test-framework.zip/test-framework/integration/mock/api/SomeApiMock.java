import org.springframework.http.HttpStatus;

public class SomeApiMock extends BaseApiMock {

    public SomeApiMock(String basePath, String mockFilesSubdirectory, MockJsonExpectations mockJsonExpectations) {
        super(basePath, mockFilesSubdirectory, mockJsonExpectations);
    }

    public void initSomeApiMock() {
        expectJson.postForPath(
                getBasePath(),
                HttpStatus.OK,
                mockFileAsString("Response.json"));
    }
}