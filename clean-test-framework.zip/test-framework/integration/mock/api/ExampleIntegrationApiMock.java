import org.springframework.http.HttpStatus;

import static org.assertj.core.api.Assertions.assertThat;

public class ExampleIntegrationApiMock extends BaseApiMock {

    private static final String API_SUB_PATH = "api/v1";
    private static final String DAGS_SUB_PATH = "dags";

    public ExampleIntegrationApiMock(String basePath, String mockFilesSubdirectory, MockJsonExpectations mockJsonExpectations) {
        super(basePath, mockFilesSubdirectory, mockJsonExpectations);
    }

    public void expectGetDagById(HttpStatus responseStatus, JsonResponseBodyExpectation responseBodyExpectation) {
        expectJson.getForPath(
                getEndpointPath(API_SUB_PATH, DAGS_SUB_PATH, DAG_ID),
                responseStatus,
                responseBodyExpectationAsString(responseBodyExpectation));
    }

    public void expectUpdateDagById(HttpStatus responseStatus, JsonRequestBodyExpectation bodyExpectation) {
        expectJson.putForPath(
                getEndpointPath(API_SUB_PATH, DAGS_SUB_PATH, DAG_ID),
                bodyExpectation,
                responseStatus);
    }

    public void verifyIfIdentityMockWasCalled(int times) {
        assertThat(expectJson.getMockInvocationCounter(
                getEndpointPath(API_SUB_PATH, DAGS_SUB_PATH, DAG_ID))).isEqualTo(times);
    }
}