
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import org.apache.commons.compress.utils.Lists;

import java.text.MessageFormat;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Value
public class JsonRequestBodyExpectation {

    List<JsonRequestBodyExpectation> expectations;
    List<JsonPropertyFilter> propertyFilters;
    ExpectationType type;

    public String asPath() {
        return type.getFilterPattern().formatted(
                type.getBuilder().apply(this));
    }

    public static JsonBodyExpectationBuilder forJsonArray() {
        return new JsonBodyExpectationBuilder(ExpectationType.ARRAY);
    }

    public static JsonBodyExpectationBuilder forJsonObject() {
        return new JsonBodyExpectationBuilder(ExpectationType.OBJECT);
    }

    public static JsonBodyExpectationBuilder forRootArrayOr() {
        return new JsonBodyExpectationBuilder(ExpectationType.ROOT_ARRAY_OR);
    }

    public static JsonBodyExpectationBuilder forRootObjectOr() {
        return new JsonBodyExpectationBuilder(ExpectationType.ROOT_OBJECT_OR);
    }

    public static JsonBodyExpectationBuilder forChildArrayOr() {
        return new JsonBodyExpectationBuilder(ExpectationType.CHILD_ARRAY_OR);
    }

    public static JsonBodyExpectationBuilder forChildObjectOr() {
        return new JsonBodyExpectationBuilder(ExpectationType.CHILD_OBJECT_OR);
    }

    @RequiredArgsConstructor
    public static class JsonBodyExpectationBuilder {

        private final List<JsonRequestBodyExpectation> expectations = Lists.newArrayList();
        private final List<JsonPropertyFilter> propertyFilters = Lists.newArrayList();
        private final ExpectationType expectationType;

        public JsonBodyExpectationBuilder expectEqualsTo(String name, String value) {
            propertyFilters.add(JsonPropertyFilter.of(name, value, FilterType.EQUALS_TO));
            return this;
        }

        public JsonBodyExpectationBuilder expectRawEqualsTo(String name, String value) {
            propertyFilters.add(JsonPropertyFilter.of(name, value, FilterType.RAW_EQUALS_TO));
            return this;
        }

        public JsonBodyExpectationBuilder expectNonBlank(String name) {
            propertyFilters.add(JsonPropertyFilter.of(name, null, FilterType.NON_BLANK));
            return this;
        }

        public JsonBodyExpectationBuilder expectation(JsonRequestBodyExpectation expectation) {
            expectations.add(expectation);
            return this;
        }

        public JsonRequestBodyExpectation build() {
            return new JsonRequestBodyExpectation(expectations, propertyFilters, expectationType);
        }

    }
    @Value(staticConstructor = "of")
    private static class JsonPropertyFilter {

        String propertyName;
        String propertyValue;
        FilterType type;
    }
    /**
     * 0 -> Base property selector
     * 1 -> relative property path
     * 2 -> property expected value
     */
    @RequiredArgsConstructor
    private enum FilterType {
        EQUALS_TO("{0}.{1} == ''{2}''"),
        RAW_EQUALS_TO("{0}.{1} == {2}"),
        NON_BLANK("{0}.{1} != '''' && {0}.{1} != null");

        @Getter
        private final String filterPattern;

    }
    @Getter
    @RequiredArgsConstructor
    private enum ExpectationType {

        OBJECT("$", "$..[?(%s)]", " && ", ExpectationType::fromPropertyFilters),
        ARRAY("@", "$[?(%s)]", " && ", ExpectationType::fromPropertyFilters),
        ROOT_OBJECT_OR("$", "$..[?(%s)]", " || ", ExpectationType::fromExpectations),
        ROOT_ARRAY_OR("@", "$[?(%s)]", " || ", ExpectationType::fromExpectations),
        CHILD_OBJECT_OR("$", "(%s)", " && ", ExpectationType::fromPropertyFilters),
        CHILD_ARRAY_OR("@", "(%s)", " && ", ExpectationType::fromPropertyFilters);

        private final String rootSelector;
        private final String filterPattern;
        private final String delimiter;
        private final Function<JsonRequestBodyExpectation, String> builder;

        private static String fromPropertyFilters(JsonRequestBodyExpectation expectation) {
            return expectation.getPropertyFilters()
                    .stream()
                    .map(toFilterExpression(expectation))
                    .collect(Collectors.joining(expectation.getType().getDelimiter()));
        }

        private static String fromExpectations(JsonRequestBodyExpectation expectation) {
            return expectation.getExpectations()
                    .stream()
                    .map(JsonRequestBodyExpectation::asPath)
                    .collect(Collectors.joining(expectation.getType().getDelimiter()));
        }

        private static Function<JsonPropertyFilter, String> toFilterExpression(JsonRequestBodyExpectation expectation) {
            return propertyFilter -> MessageFormat.format(
                    propertyFilter.getType().getFilterPattern(),
                    expectation.getType().getRootSelector(),
                    propertyFilter.getPropertyName(),
                    propertyFilter.getPropertyValue());
        }
    }
}