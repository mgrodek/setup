import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.util.UriBuilder;

public class ServiceApiTestClient extends BaseTestClient {

    public ServiceApiTestClient(WebTestClient testClient) {
        super(testClient);
    }

    @Override
    protected String basePath() {
        return "/api/v1";
    }

    public WebTestClient.ResponseSpec deleteDag() {
        return doDelete((UriBuilder uriBuilder) -> uriBuilder.pathSegment(DAG_ID));
    }

    public WebTestClient.ResponseSpec getDag() {
        return doGet((UriBuilder uriBuilder) -> uriBuilder.pathSegment(DAG_ID));
    }
}