
import org.junit.jupiter.api.Test;
import org.springframework.test.web.reactive.server.WebTestClient;

public class ServiceApiControllerIT extends BaseNoAuthorizationIT<ServiceApiTestClient> {

    @Override
    public ServiceApiTestClient getTestClient(WebTestClient testClient) {
        return new ServiceApiTestClient(testClient);
    }

    @Test
    void deleteDag() {
        // when
        var response = testClient.deleteDag();

        // then
        response
                .expectStatus().is5xxServerError();
    }


    @Test
    void getDag() {
        // when
        var response = testClient.getDag();

        // then
        response
                .expectStatus().is5xxServerError();
    }
}