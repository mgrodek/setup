
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DagRequests {

    public static JsonRequestBodyExpectation getDag(String dagId) {
        return JsonRequestBodyExpectation.forJsonObject()
                .expectEqualsTo("dagId", dagId)
                .expectRawEqualsTo("foo", "true")
                .build();
    }
}