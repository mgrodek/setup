
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DagResponse {

    public static JsonResponseBodyExpectation getEmptyResponse() {
        return aJsonResponseBodyExpectation()
                .build();
    }

    public static JsonResponseBodyExpectation getDagData() {
        return aJsonResponseBodyExpectation()
                .withProperty("dagData", aJsonResponseBodyExpectation()
                        .asArray()
                        .withElement(aJsonResponseBodyExpectation()
                                .withProperty("key", "value")
                                .withProperty("additions", aJsonResponseBodyExpectation()
                                        .withProperty("subKey", 0)
                                        .withProperty("date", LocalDate.now().toString())
                                        .build())
                                .build())
                        .build())
                .build();
    }
}