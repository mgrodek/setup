
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.reactive.server.WebTestClient;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockserver.matchers.Times.once;

public class SomeApiControllerIT extends BaseNoAuthorizationIT<SomeApiTestClient> {

    @Override
    public SomeApiTestClient getTestClient(WebTestClient testClient) {
        return new SomeApiTestClient(testClient);
    }

    @ParameterizedTest
    @MethodSource
    void testGetDagInfo(String response, JsonResponseBodyExpectation jsonResponseBodyExpectation) {
        // mock
        serviceApiMock.expectGetDagInfo(
                HttpStatus.OK,
                response,
                once());
       serviceApiMock.expectGetDagInfo(
                HttpStatus.CREATED,
                jsonResponseBodyExpectation);

        // when
        var response = testClient.getDagInfo(token());

        // then
        response
                .expectStatus().isOk()
                .expectBody(ResponseBody.class).isEqualTo(expectedResponse);
    }

    private static Stream<Arguments> testGetDagInfo() {
        return Stream.of(
                Arguments.of(
                        "SomeResponse",
                        expectedTestData()));
    }
}