import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.util.UriBuilder;

public class SomeApiTestClient extends BaseTestClient {

    public SomeApiTestClient(WebTestClient testClient) {
        super(testClient);
    }

    @Override
    protected String basePath() {
        return "/some-api/v1";
    }

    public WebTestClient.ResponseSpec getDag() {
        return doGet((UriBuilder uriBuilder) -> uriBuilder.pathSegment("dag"));
    }

    public WebTestClient.ResponseSpec updateDag(Request requestBody, String token) {
        return doPut((UriBuilder uriBuilder) -> uriBuilder.pathSegment("dag"), authorizationHeaders(token), requestBody);
    }

    public WebTestClient.ResponseSpec getDagInfo() {
        return doGet((UriBuilder uriBuilder) -> uriBuilder
                .pathSegment("dag-info")
                .pathSegment("foo")
                .queryParam("bar", "1"));
    }
}