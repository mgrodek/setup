import org.springframework.web.util.UriBuilder;

@FunctionalInterface
public interface UriConfigurer {

    void configure(UriBuilder uriComponentsBuilder);
}